﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tabuleiro
{
    enum Cor
    {
        Branca,
        Preta,
        Amarela,
        Vermelha,
        Laranja
    }
}
