﻿using System;
using tabuleiro;

    internal class TabuleiroException : Exception
{
    public TabuleiroException(string msg) : base(msg) {
    }
}
    


